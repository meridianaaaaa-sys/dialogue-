# Dialogue — Android (WebView-обёртка)

## Способ 1: GitHub Actions (без Android Studio)
1. Создайте репозиторий на github.com и загрузите в него содержимое этой папки (включая `.github`).
2. Вкладка **Actions** → «Build APK» запустится сама (или Run workflow).
3. Через 3–5 минут скачайте `Dialogue.apk` в **Releases** (или Artifacts запуска).
4. Откройте APK на телефоне, разрешите установку из неизвестных источников.

## Способ 2: Android Studio
File → Open → выберите эту папку → Build → Build APK(s). Файл: `app/build/outputs/apk/release/`.

Подпись: `app/dialogue.keystore` (пароль `dialogue123`, alias `dialogue`) — публичный, для публикации в магазине создайте свой.
