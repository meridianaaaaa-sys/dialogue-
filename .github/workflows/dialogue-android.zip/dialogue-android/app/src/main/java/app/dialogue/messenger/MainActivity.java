package app.dialogue.messenger;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Dialogue: оболочка WebView. Страница лежит в assets и открывается по https-адресу
 * appassets.androidplatform.net, поэтому работают getUserMedia, IndexedDB и localStorage.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILE = 1001;
    private static final int REQ_MEDIA = 1002;
    private static final int REQ_GEO = 1003;
    private static final int REQ_NOTIF = 1004;
    private static final String CHANNEL_ID = "messages";
    private static final int BG = 0xFF0B0B0D;

    private WebView web;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingMedia;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private int notifCounter = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web = new WebView(this);
        web.setBackgroundColor(BG);
        setContentView(web);
        configureWebView();
        web.loadUrl(START_URL);
    }

    private void configureWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setGeolocationEnabled(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleMediaRequest(request);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    callback.invoke(origin, true, false);
                    return;
                }
                if (pendingGeoCallback != null) {
                    pendingGeoCallback.invoke(pendingGeoOrigin, false, false);
                }
                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    toast("Не удалось открыть выбор файлов");
                }
                return true;
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url.startsWith("blob:")) {
                saveBlobUrl(url, URLUtil.guessFileName(url, contentDisposition, mimeType), false);
            } else if (url.startsWith("data:")) {
                saveDataUrl(url, URLUtil.guessFileName(url, contentDisposition, mimeType), mimeType, false);
            } else {
                openExternal(Uri.parse(url));
            }
        });
    }

    // ---------- ссылки ----------

    private boolean handleUrl(Uri u) {
        String scheme = u.getScheme();
        if (scheme == null) {
            return false;
        }
        if ("blob".equals(scheme)) {
            saveBlobUrl(u.toString(), "", true);
            return true;
        }
        if ("data".equals(scheme) || "about".equals(scheme) || "javascript".equals(scheme)) {
            return false;
        }
        if (("https".equals(scheme) || "http".equals(scheme)) && HOST.equals(u.getHost())) {
            return false;
        }
        openExternal(u);
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Нет приложения для открытия ссылки");
        }
    }

    // ---------- разрешения для камеры и микрофона ----------

    private boolean has(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void handleMediaRequest(PermissionRequest request) {
        List<String> need = new ArrayList<String>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !has(Manifest.permission.RECORD_AUDIO)) {
                need.add(Manifest.permission.RECORD_AUDIO);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !has(Manifest.permission.CAMERA)) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            grantMedia(request);
            return;
        }
        if (pendingMedia != null) {
            pendingMedia.deny();
        }
        pendingMedia = request;
        requestPermissions(need.toArray(new String[0]), REQ_MEDIA);
    }

    private void grantMedia(PermissionRequest request) {
        List<String> ok = new ArrayList<String>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) {
            request.deny();
        } else {
            request.grant(ok.toArray(new String[0]));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA) {
            PermissionRequest r = pendingMedia;
            pendingMedia = null;
            if (r != null) {
                grantMedia(r);
            }
        } else if (requestCode == REQ_GEO) {
            boolean ok = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (pendingGeoCallback != null) {
                pendingGeoCallback.invoke(pendingGeoOrigin, ok, false);
            }
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    // ---------- выбор файлов ----------

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        }
    }

    // ---------- кнопка «Назад» ----------

    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
                "(function(){try{return window.__dlgBack?window.__dlgBack():false;}catch(e){return false;}})()",
                value -> {
                    if (!"true".equals(value)) {
                        moveTaskToBack(true);
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    // ---------- сохранение файлов ----------

    private static String jsString(String s) {
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    private static String sanitize(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return n.isEmpty() ? "file" : n;
    }

    private void saveBlobUrl(String url, String name, boolean open) {
        String js = "(function(){fetch(" + jsString(url) + ").then(function(r){return r.blob();}).then(function(b){"
                + "var fr=new FileReader();fr.onloadend=function(){AndroidBridge.saveBase64(fr.result,"
                + jsString(name) + ",b.type||''," + open + ");};fr.readAsDataURL(b);})"
                + ".catch(function(e){AndroidBridge.saveBase64('','','',false);});})();";
        web.evaluateJavascript(js, null);
    }

    private void saveDataUrl(String dataUrl, String name, String mime, boolean open) {
        try {
            int comma = dataUrl.indexOf(',');
            if (!dataUrl.startsWith("data:") || comma < 0) {
                throw new IllegalArgumentException("bad data url");
            }
            String head = dataUrl.substring(5, comma);
            String type = head.contains(";") ? head.substring(0, head.indexOf(';')) : head;
            if (mime == null || mime.isEmpty()) {
                mime = type;
            }
            byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
            if (name == null || name.isEmpty()) {
                String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
                name = "dialogue-file" + (ext != null ? "." + ext : "");
            }
            saveBytes(name, mime, bytes, open);
        } catch (Exception e) {
            toast("Не удалось сохранить файл");
        }
    }

    private void saveBytes(String name, String mime, byte[] data, boolean open) {
        try {
            String safe = sanitize(name);
            if (mime == null || mime.isEmpty()) {
                mime = "application/octet-stream";
            }
            Uri uri = null;
            String where;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Dialogue");
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) {
                    throw new IllegalStateException("MediaStore insert failed");
                }
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) {
                    throw new IllegalStateException("no output stream");
                }
                try {
                    out.write(data);
                } finally {
                    out.close();
                }
                where = "Загрузки/Dialogue";
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) {
                    throw new IllegalStateException("no storage");
                }
                File f = new File(dir, safe);
                FileOutputStream out = new FileOutputStream(f);
                try {
                    out.write(data);
                } finally {
                    out.close();
                }
                where = f.getAbsolutePath();
            }
            toast("Сохранено: " + where);
            if (open && uri != null) {
                openSaved(uri, mime);
            }
        } catch (Exception e) {
            toast("Не удалось сохранить файл");
        }
    }

    private void openSaved(Uri uri, String mime) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            // нет приложения для этого типа — файл уже сохранён
        }
    }

    private void toast(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ---------- уведомления ----------

    private void postNotification(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            return;
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Сообщения", NotificationManager.IMPORTANCE_HIGH));
            nb = new Notification.Builder(this, CHANNEL_ID);
        } else {
            nb = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        nb.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(pi)
                .setAutoCancel(true);
        notifCounter = notifCounter % 1000 + 1;
        nm.notify(notifCounter, nb.build());
    }

    // ---------- мост для JavaScript ----------

    public class Bridge {
        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public void saveText(String name, String text, String mime) {
            saveBytes(name, mime, text.getBytes(java.nio.charset.StandardCharsets.UTF_8), false);
        }

        @JavascriptInterface
        public void saveBase64(String dataUrl, String name, String mime, boolean open) {
            if (dataUrl == null || dataUrl.isEmpty()) {
                toast("Не удалось сохранить файл");
                return;
            }
            saveDataUrl(dataUrl, name, mime, open);
        }

        @JavascriptInterface
        public void showNotification(final String title, final String body) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    postNotification(title, body);
                }
            });
        }

        @JavascriptInterface
        public void requestNotifications() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                    }
                }
            });
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean lightBackground) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        int c = Color.parseColor(color.trim());
                        Window w = getWindow();
                        w.setStatusBarColor(c);
                        w.setNavigationBarColor(c);
                        web.setBackgroundColor(c);
                        View d = w.getDecorView();
                        int f = d.getSystemUiVisibility();
                        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        if (Build.VERSION.SDK_INT >= 26) {
                            light |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        }
                        f = lightBackground ? (f | light) : (f & ~light);
                        d.setSystemUiVisibility(f);
                    } catch (IllegalArgumentException e) {
                        // неверный цвет — оставляем как есть
                    }
                }
            });
        }
    }
}
